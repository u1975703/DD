package com.example.teamproject;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MeasurmentsScreen extends AppCompatActivity {
    TextView resultBMR;
    EditText numAge, numHeight, numWeight;
    Button BMRcal;
    public static final String BMR_num = "MyprestFile";
    @SuppressLint("CutPasteId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_measurments_screen);

        TextView tex =(TextView) findViewById(R.id.textView22);
        tex.setMovementMethod(LinkMovementMethod.getInstance());

        numAge =  findViewById(R.id.etAge);
        numWeight = findViewById(R.id.etWeight);
        numHeight = findViewById(R.id.etWeight);
        BMRcal = findViewById(R.id.btnBMR);
        resultBMR = findViewById(R.id.twBMR);


        BMRcal.setOnClickListener(v -> {
            if(numAge.getText().toString().length() == 0){
                numAge.setText("0");
            }
            if(numWeight.getText().toString().length() == 0){
                numWeight.setText("0");
            }
            int age = Integer.parseInt(numAge.getText().toString());
            int weight = Integer.parseInt(numWeight.getText().toString());
            int height = Integer.parseInt(numHeight.getText().toString());
            int BMR = (int) (88.362 +(13.397*weight) + (4.799*height) - (5.677*age));
            resultBMR.setText(String.valueOf(BMR));
            DailGoalScreen.BMR = BMR;

        });
    }
    public void launchBack(View v){
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }
    public void launchDailGoalScreen(View v){
        Intent i = new Intent(this, DailGoalScreen.class);
        startActivity(i);
    }
}