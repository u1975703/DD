package com.example.teamproject;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class DailGoalScreen extends AppCompatActivity {
    TextView resultCal,totalCalories;
    static int BMR;
    int caloriesTotal;
    int caloriesLeft;
    EditText caloriesiput,numCalinput ;
//    Button caloriesMinus;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MeasurmentsScreen m = new MeasurmentsScreen();
        caloriesiput = findViewById(R.id.etCaloriesIntake);

        caloriesTotal = (int) (BMR *1.2);
        setContentView(R.layout.activity_dail_goal_screen);
        resultCal = findViewById(R.id.CaloriesLeft);
        totalCalories = findViewById(R.id.Calories);
        totalCalories.setText(String.valueOf(caloriesTotal));
        resultCal.setText(String.valueOf(caloriesTotal));
        numCalinput = findViewById(R.id.etCaloriesIntake);



    }
    public void caloriesintake (View v){

        int calinput = Integer.parseInt((numCalinput.getText().toString()));
        caloriesTotal = caloriesTotal - calinput;
        resultCal.setText(String.valueOf(caloriesTotal));
    }
    public void launchBack(View v){
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }
}