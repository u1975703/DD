package com.example.teamproject;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;

public class LogInScreen extends AppCompatActivity {

    GoogleSignInOptions gso;
    GoogleSignInClient gsc;
    SignInButton googleBtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        Log.d("MyTag","********");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in_screen);

        TextView t =(TextView) findViewById(R.id.textView20);
        t.setMovementMethod(LinkMovementMethod.getInstance());

//        TextView text =(TextView) findViewById(R.id.textView19);
//        text.setMovementMethod(LinkMovementMethod.getInstance());

        googleBtn = findViewById(R.id.google_sign_in);

        gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestEmail().build();
        gsc = GoogleSignIn.getClient(this, gso);

        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);
        if(acct!=null){
            navigateToMainActivity();
        }


        googleBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                signIn();
            }
        });
    }

    void signIn(){
        Intent signInIntent =gsc.getSignInIntent();
        startActivityForResult(signInIntent, 1000);
        Log.d("Test", "&&&&&&&");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
       Log.d("MyTag","111"+ resultCode);
       if(resultCode == -1){

            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);

            try {
                task.getResult(ApiException.class);
                Log.d("2:    ","222"+ task.getResult(ApiException.class));
                navigateToMainActivity();
            } catch (ApiException e) {
                Toast.makeText(getApplicationContext(), "Something went wrong", Toast.LENGTH_SHORT).show();
            }
        }
    }
    void navigateToMainActivity(){
        finish();
        Intent intent = new Intent(LogInScreen.this, MainActivity.class);
        startActivity(intent);
    }
}